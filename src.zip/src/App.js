// import logo from './logo.svg';

import './App.css';
import Transaction from './component/transaction';
// import Description from './component/Descript';
import Formcomponent from './component/Formcompo';
import Navbar1 from './component/nav';
import React, { useEffect, useState } from 'react';
import Footer from './component/footer';
import Datacontext from './data/Datacontext';
import ReportCompo from './component/ReportComponent';
import {BrowserRouter as Router,Switch,Route,Link,Routes} from "react-router-dom";
import HelloCompo from './component/hello';

// const Title =()=> <h1> 	Income-Outcome</h1>

//main function
function App() {
  // const design = {color: 'darkblue', textAlign: 'center', fontSize: '3rem',padding}
  const initdata = [
    {id:1,title:'travel',amount:- 2000},
    {id:2,title:'food',amount:- 1000},
    {id:3,title:'salary',amount:+ 30000},
    {id:4,title:'shopping',amount:- 500},
    {id:5,title:'drinking',amount:- 3000},
    {id:6,title:'pencil',amount:+ 3000}
]
  const onaddNewitem =(newitem)=>{
    SetItem((prev_item)=>{
      return [newitem,...prev_item]
    })
  }
  const [items, SetItem] = useState(initdata)
  const [incomerep, IncomeReport] = useState(0)
  const [outcomerep, OutcomeReport] = useState(0)

  useEffect (()=>{
    const amounts = items.map(items=>items.amount)
    const income = amounts.filter(element=>element>0).reduce((result,element)=>result+=element,0)
    const outcome = (amounts.filter(element=>element<0).reduce((result2,element)=>result2+=element,0))*-1
    IncomeReport(income)
    OutcomeReport(outcome)
    console.log("this")

  },[items,incomerep,outcomerep])
   return (

        <Datacontext.Provider value={
      {
        income: incomerep,
        expense: outcomerep
      }
    }>
    <div>
    <div className='nav'>
    <Navbar1/>
    </div>
    <div className='container'>
      <h1>Income-Outcome</h1>
       
      <ReportCompo/>
      <Formcomponent onAddItem={onaddNewitem}/>
      {/* <Description/> */}
      <Transaction items = {items}/>
    </div>
    <Footer/>
    </div>
    </Datacontext.Provider>
  
  );
}

export default App;
