import './nav.css';

function Navbar1() {
  return (
    <div className="topnav">
  <a className="active" href="http://localhost:3000">Home</a>
  <a href="https://github.com/pattanan-pr">Contact</a>

   
</div>
  );
}

export default Navbar1;