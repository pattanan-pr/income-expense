import Item1 from "./item";
import './transac.css';
// import Datacontext from "../data/Datacontext";
// import { useContext } from "react";

const Transaction =(props)=> {
    const {items} = props
    return(
      <div>
        <ul className="item-list">
        {items.map((element)=>{
          return <Item1 key={element.id} title={element.title} amount={element.amount}/>
        })}
      </ul>
      {/* {name} */}
    </div>
    );
  }
  export default Transaction