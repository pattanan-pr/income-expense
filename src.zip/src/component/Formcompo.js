import './formcompo.css'; 
import React, { useState, useEffect } from 'react';
import { v4 as uuidv4 } from 'uuid';

const Formcomponent = (props)=> {
    const [title, SetTitle] = useState('')
    const [amount, SetAmount] = useState(0)
    const [formvalid, SetValid] = useState(false)

    const inputTitle = (event)=>{
        SetTitle(event.target.value)
    }
    const inputAmount = (event)=>{
        SetAmount(event.target.value)
    }
    const subMit = (event)=>{
        console.log("succeed!")
        event.preventDefault()
        const ItemData = {
            id:uuidv4(),
            title:title,
            amount: Number(amount)
        }
        props.onAddItem(ItemData)
        SetTitle('')
        SetAmount(0)
    }
    useEffect (()=>{
        const checkData = title.trim().length>0 && amount !==0
        if(checkData){
            SetValid(true)
        }
    },[amount,title])

    return(
        <div>
            <form onSubmit={subMit}>
                <div className="form-control">
                    <label>Item name</label>
                    <input type='text' placeholder=' input your item' onChange={inputTitle} value={title}/>
                </div>
                <div className="form-control">
                    <label>Amount</label>
                    <input type='number' placeholder='(+ Income , - Outcome)' onChange={inputAmount} value={amount}/>
                </div>
                <div>
                    <button type='submit' className='btn' disabled={!formvalid}>submit</button>
                </div>
            </form>
        </div>
    )
}
export default Formcomponent