// import './transac.css'
import PropTypes from 'prop-types';
import "./Item.css"
// import { useContext } from "react";


const Item1 =({title, amount})=> {
    // const name = 'Travel'
    // const amount = 200
    // const {title, amount} = props
    const status = amount<0 ? "expense":"income"
    const symbol = amount<0 ? "-":"+"
    return(
    <li className={status}> {symbol} &nbsp; {title} <span> {Math.abs(amount)} {"Bath"}</span></li>
    );
}

Item1.propTypes= {title:PropTypes.string.isRequired, amount:PropTypes.number.isRequired}
// const Item2 =()=> <li>cloths<span>- 1000</span></li>
// const Item3 =()=> <li>food <span>- 200</span></li>

export default Item1
