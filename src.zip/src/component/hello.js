import React from 'react';

function HelloCompo() {
      return (
        <div>
      <h1>Incone-Outcome app</h1>
      <p>record income and expenses and the calculation</p>
      </div>
      );

  }
export default HelloCompo