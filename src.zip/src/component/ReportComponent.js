import { useContext } from "react";
import Datacontext from "../data/Datacontext";

const ReportCompo=()=>{
    const {income, expense} = useContext(Datacontext)
    const remaining = income-expense
    const resultRemain = remaining>0 ? "plus":"minus"
    return(
    <div>
        <div className={resultRemain}>
        <p>Remaining<br></br>{((income-expense).toLocaleString("en-US"))}</p>
        </div>
        <div className="compo-inout">
            <div className="income-style">
                    <h3>Total income<br></br>{income.toLocaleString("en-US")}</h3>
            </div>
            <div className="outcome-style">
                    <h3>Total outcome<br></br>{expense.toLocaleString("en-US")}</h3>
            </div>
        </div>
    </div>
    );
}
export default ReportCompo