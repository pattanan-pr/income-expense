import "./Footer.css"
const Footer = ()=> {
    return (
        <div className="fixed-footer">
            <div className="containers">
            {/* <a href="https://github.com/pattanan-pr">Github</a> */}
            <p></p>
            </div>        
        </div>
    );
}

export default Footer
